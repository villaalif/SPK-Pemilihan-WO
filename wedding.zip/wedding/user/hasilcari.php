<?php include 'header.php'?>

<head>
  <style>
    /* Gaya untuk card */
    .card {
      border: 1px solid #ccc; /* Tambahkan garis tepi (border) sepanjang 1px dengan warna #ccc */
      padding: 10px; /* Tambahkan ruang padding di dalam card */
      margin-bottom: 20px; /* Tambahkan ruang margin di bagian bawah card */
    }

    /* Gaya untuk judul card */
    .card-title {
      margin-top: 0;
    }
  </style>

  <!-- Sisipkan sumber daya lainnya di sini seperti link ke file CSS eksternal, dll. -->
</head>

<header id="fh5co-header" class="fh5co-cover" >			
  <div class="col-md-8 col-md-offset-2 text-center">
    <div style="margin: 50px;">
      <!-- Isi elemen Anda di sini -->
    </div>

    <div class="display-t">
      <div class="display-tc animate-box" data-animate-effect="fadeIn">
       <h1 style= "color:black;" >Hasil Pencarian WO</h1>

       <div class="row">
        <?php 

        $encoded_data = $_GET['data'];
        if ($encoded_data) {
          $json_data = urldecode($encoded_data);
          $data = json_decode($json_data, true);

          foreach ($data as $i => $row) {
  // Format harga menjadi mata uang Rupiah
            $formatted_harga = number_format($row["harga"], 0, ",", ".");

            echo '<div class="col-sm-4">
            <div class="card">
            <div class="card-body">
            <h3 class="card-title">Pilihan ' . ($i + 1) . '</h3>
            <h4 class="card-title">' . $row["nama_alternatif"] . '</h4>
            <p class="card-text text-justify" style="margin-left: 25px;">
            Tahun: ' . $row["tahun"] . '<br>
            Harga: Rp ' . $formatted_harga . '<br> <!-- Harga dengan format Rupiah -->
            Rating: ' . $row["rating"] . '<br>
            Jumlah Kursi: ' . $row["jml_kursi"] . '<br>
            Jumlah Baju: ' . $row["jml_baju"] . '<br>
            </p>
            </div>
            </div>
            </div>';
          }
        } else {
          echo "<p>Data tidak ditemukan </p>";
        }
        
        ?>
      </div>

    </div>
  </div>
</div>
</div>
</div>
</div>
</header> <p align="center">
  <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> </p>

  <div class="gototop js-top">
    <a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
  </div>

  <!-- jQuery -->
  <script src="assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- Carousel -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- countTo -->
  <script src="assets/js/jquery.countTo.js"></script>

  <!-- Stellar -->
  <script src="assets/js/jquery.stellar.min.js"></script>
  <!-- Magnific Popup -->
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/magnific-popup-options.js"></script>

  <!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
  <script src="assets/js/simplyCountdown.js"></script>
  <!-- Main -->
  <script src="assets/js/main.js"></script>


</body>
</html>