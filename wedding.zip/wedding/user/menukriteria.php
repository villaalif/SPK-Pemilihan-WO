<?php include 'header.php'?>

	<header id="fh5co-header" class="fh5co-cover" >
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1 style="color:black;" >Menu Kriteria</h1><br><br>
							<table style="color:black;" class="table table-bordered">
                     <thead>
                        <tr>
                          <th class="text-center">Nama Kriteria</th>
                          <th class="text-center">Tipe Kriteria</th>
                          <th class="text-center">Bobot</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php  
                    include '../koneksi.php';
                    $query_tampil = mysqli_query($koneksi, "SELECT * FROM kriteria" ) or die (mysqli_error($koneksi));

                    while ($b = mysqli_fetch_assoc($query_tampil)) {
                        ?>

                        <tr>
                            <td ><?= $b['nama_kriteria']; ?></td>
                            <td ><?= $b['tipe_kriteria']; ?> </td>
                            <td ><?= $b['bobot']; ?></td>
                      </tr>
                      
                      <?php  
                  }
                  ?>     
              </tbody>
          </table><br><p>
						<small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> 
					</p>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div class="gototop js-top">
		<a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="assets/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="assets/js/jquery.countTo.js"></script>

	<!-- Stellar -->
	<script src="assets/js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/magnific-popup-options.js"></script>

	<!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
	<script src="assets/js/simplyCountdown.js"></script>
	<!-- Main -->
	<script src="assets/js/main.js"></script>


	</body>
</html>

