<?php include 'header.php'?>
  
  <br><br>
  <div id="fh5co-gallery" class="fh5co-section-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
          <span>Galeri</span>
          <h2 style="color: black;">Wedding Dian</h2>
          <p>Dian Wedding Organizer berdiri sejak tahun 1997. Yang berlokasi di Jl. Cendrawasih Kelurahan No.23, Tengkerang Tengah, Kec. Marpoyan Damai. Kami menerima potong rambut, creambeth facial,totok wajah, spa, lulur dan juga kami menyediakan pelaminan tenda, orgen, photo dan shooting. Silahkan datang ke outlate kami.</p>
        </div>
      </div>
      <div class="row row-bottom-padded-md">
        <div class="col-md-12">
          <ul id="fh5co-gallery-list">
            
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/1.jpg); "> 
              <div class="case-studies-summary">
              </div>
            </a>
          </li>
          
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/2.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/3.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/5.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/4.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/dian/6.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>
          </ul>   
        </div>
      </div>
    </div>
  </div>

  

  <footer id="fh5co-footer" role="contentinfo">
    <div class="container">

      <div class="row copyright">
        <div class="col-md-12 text-center">
          <p>
            <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> 
          </p>
          
        </div>
      </div>

    </div>
  </footer>
  </div>

  <div class="gototop js-top">
    <a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
  </div>
  
  <!-- jQuery -->
  <script src="assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- Carousel -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- countTo -->
  <script src="assets/js/jquery.countTo.js"></script>

  <!-- Stellar -->
  <script src="assets/js/jquery.stellar.min.js"></script>
  <!-- Magnific Popup -->
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/magnific-popup-options.js"></script>

  <!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
  <script src="assets/js/simplyCountdown.js"></script>
  <!-- Main -->
  <script src="assets/js/main.js"></script>

  </body>
</html>

