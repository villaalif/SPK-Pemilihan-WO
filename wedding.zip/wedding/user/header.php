<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
		<link rel="shortcut icon" href="assets/images/logo.png">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SPK Wedding Organizer</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="assets/css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="assets/css/style.css">

	<!-- Modernizr JS -->
	<script src="assets/js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div  class="fh5co-loader"></div>
	
	<div  id="page">
	<nav style="background-image: linear-gradient(to bottom right, #13547a, #80d0c7);" class="fh5co-nav" role="navigation">
		<div  class="container">
			<div  class="row">
				<div  class="col-xs-5">
					<div id="fh5co-logo"><a href="index.php">Woky Wedding Planner</a></div>
				</div>
				<div class="col-xs-15 text-right menu-5">
					<ul>
						<li><a href="index.php">Home</a></li>
						<!-- <li><a href="menukriteria.php">Menu Kriteria</a></li> -->
						<li><a href="menualternatif.php">Menu Alternatif</a></li>
						<!-- <li><a href="test.php">Menu</a></li> -->
						<li><a href="menu_vektorv.php">Nilai Preferensi</a></li>
						<li><a href="cariwo.php">Cari WO</a></li>
						<li class="has-dropdown">
							<a href="#">Daftar WO</a>
							<ul class="dropdown">
								<li><a href="dian.php">Wedding Dian</a></li>
								<li><a href="global.php">Global Wedding</a></li>
								<li><a href="sumayyah.php">Sumayyah Wedding</a></li>
								<li><a href="kharisma.php">Kharisma Wedding</a></li>
							</ul>
						</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>