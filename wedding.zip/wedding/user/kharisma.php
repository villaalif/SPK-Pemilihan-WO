<?php include 'header.php'?>
  
  <br><br>
  <div id="fh5co-gallery" class="fh5co-section-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
          <span>Galeri</span>
          <h2 style="color: black;">Kharisma Wedding</h2>
          <p>Kharisma Wedding Organizer terletak dijalan bakti, samping alwafa hijab. Melayani jasa sewa pelaminan, pakaian pengantin, tenda, kursi, catering, make up. Berdiri sejak tahun 1995, dikerjakan oleh tenaga ahli dibidangnya. Kharisma wedding mengutamakan pelayanan dan kepuasan pelanggan.</p>
        </div>
      </div>
      <div class="row row-bottom-padded-md">
        <div class="col-md-12">
          <ul id="fh5co-gallery-list">
            
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/1.jpg); "> 
              <div class="case-studies-summary">
              </div>
            </a>
          </li>
          
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/5.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/3.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/2.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/6.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/kharisma/4.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>
          </ul>   
        </div>
      </div>
    </div>
  </div>

  

  <footer id="fh5co-footer" role="contentinfo">
    <div class="container">

      <div class="row copyright">
        <div class="col-md-12 text-center">
          <p>
            <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> 
          </p>
          
        </div>
      </div>

    </div>
  </footer>
  </div>

  <div class="gototop js-top">
    <a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
  </div>
  
  <!-- jQuery -->
  <script src="assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- Carousel -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- countTo -->
  <script src="assets/js/jquery.countTo.js"></script>

  <!-- Stellar -->
  <script src="assets/js/jquery.stellar.min.js"></script>
  <!-- Magnific Popup -->
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/magnific-popup-options.js"></script>

  <!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
  <script src="assets/js/simplyCountdown.js"></script>
  <!-- Main -->
  <script src="assets/js/main.js"></script>

  </body>
</html>

