<?php include 'header.php'?>
  
  <br><br>
  <div id="fh5co-gallery" class="fh5co-section-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
          <span>Galeri</span>
          <h2 style="color: black;">Sumayyah Wedding</h2>
          <p>Sumayyah Wedding Organizer merupakan salah satu WO yang berlokasi di Tampan ini cocok buat kamu yang dari sekitaran Panam, Pekanbaru. </p>
        </div>
      </div>
      <div class="row row-bottom-padded-md">
        <div class="col-md-12">
          <ul id="fh5co-gallery-list">
            
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/1.jpg); "> 
              <div class="case-studies-summary">
              </div>
            </a>
          </li>
          
            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/3.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/4.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/2.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/5.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>

            <li class="one-third animate-box" data-animate-effect="fadeIn" style="background-image: url(assets/images/sumayyah/6.jpg); "> 
                <div class="case-studies-summary">
                </div>
              </a>
            </li>
          </ul>   
        </div>
      </div>
    </div>
  </div>

  

  <footer id="fh5co-footer" role="contentinfo">
    <div class="container">

      <div class="row copyright">
        <div class="col-md-12 text-center">
          <p>
            <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> 
          </p>
          
        </div>
      </div>

    </div>
  </footer>
  </div>

  <div class="gototop js-top">
    <a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
  </div>
  
  <!-- jQuery -->
  <script src="assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- Carousel -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- countTo -->
  <script src="assets/js/jquery.countTo.js"></script>

  <!-- Stellar -->
  <script src="assets/js/jquery.stellar.min.js"></script>
  <!-- Magnific Popup -->
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/magnific-popup-options.js"></script>

  <!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
  <script src="assets/js/simplyCountdown.js"></script>
  <!-- Main -->
  <script src="assets/js/main.js"></script>

  </body>
</html>

