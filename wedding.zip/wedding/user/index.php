<!DOCTYPE html> <html class="no-js"> <!--<![endif]-->
	<head>
		<link rel="shortcut icon" href="assets/images/logo.png">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SPK Wedding Organizier</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

	<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Sacramento" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="assets/css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="assets/css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="assets/css/style.css">

	<!-- Modernizr JS -->
	<script src="assets/js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div  class="fh5co-loader"></div>
	
	<div  id="page">
	<nav  class="fh5co-nav" role="navigation">
		<div  class="container">
			<div  class="row">
				<div  class="col-xs-5">
					<div id="fh5co-logo"><a href="index.php">Woky Wedding Planner</a></div>
				</div>
				<div class="col-xs-15 text-right menu-5">
					<ul>
						<li><a href="index.php" style="color: white;">Home</a></li>
						<!-- <li><a href="menukriteria.php" style="color: white;">Menu Kriteria</a></li> -->
						<li><a href="menualternatif.php" style="color: white;">Menu Alternatif</a></li>
						<!-- <li><a href="test.php" style="color: white;">Menu</a></li> -->
						<li><a href="menu_vektorv.php" style="color: white;">Nilai Preferensi</a></li>
						<li><a href="cariwo.php" style="color: white;">Cari WO</a></li>
						<li class="has-dropdown">
							<a href="#" style="color: white;">Daftar WO</a>
							<ul class="dropdown">
								<li><a href="dian.php">Wedding Dian</a></li>
								<li><a href="global.php">Global Wedding</a></li>
								<li><a href="sumayyah.php">Sumayyah Wedding</a></li>
								<li><a href="kharisma.php">Kharisma Wedding</a></li>
							</ul>
						</li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

	<header id="fh5co-header" class="fh5co-cover" style="background-image: url(assets/images/bga.jpg);" >
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1>Selamat Datang</h1>
						</div>
					</div>
				</div>
	</header>

	<div id="fh5co-testimonial">
		<div class="container">
			<div class="row">
				<div class="row animate-box">
				</div>
				<div class="row">
					<div class="col-md-12 animate-box">
						<div class="wrap-testimony">
							<div class="owl-carousel-fullwidth">
								<div class="item">
									<div class="testimony-slide active text-center">
										<span style="font-size: 15px;">Tentang Kami</span>
										<blockquote>
											<p>
											Woky Wedding Planner merupakan website bagi para calon pengantin yang bingung mencari wedding organizier yang cocok. Disini kami memberikan beberapa WO, dan merekomendasikan WO terbaik.</p>
										</blockquote>
									</div>
								</div>
								<div class="item">
									<div class="testimony-slide active text-center">
										<span style="font-size: 15px;">Nilai</span>
										<blockquote>
											<p> Untuk membangun reputasi dan mengembangkan merek “Woky Wedding Planner” untuk jangka panjang, kami melakukan yang terbaik untuk melakukan bisnis secara profesional dan dapat dipercaya dan juga  melakukan yang terbaik untuk sentuhan inovatif dan kreatif. </p>
										</blockquote>
									</div>
								</div>
								<div class="item">
									<div class="testimony-slide active text-center">
										<span style="font-size: 15px;" >Hubungi Kami</span>
										<blockquote>
											<p>Hotline & WhatsApp: +6281238490222
											<br>Email : WokyWP@gmail.com</p>
										</blockquote>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<footer id="fh5co-footer" role="contentinfo">
    <div class="container">

      <div class="row copyright">
        <div class="col-md-12 text-center">
          <p>
            <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> 
          </p>
          
        </div>
      </div>

    </div>
  </footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="assets/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="assets/js/jquery.countTo.js"></script>

	<!-- Stellar -->
	<script src="assets/js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/magnific-popup-options.js"></script>

	<!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
	<script src="assets/js/simplyCountdown.js"></script>
	<!-- Main -->
	<script src="assets/js/main.js"></script>


	</body>
</html>

