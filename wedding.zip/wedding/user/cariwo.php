<?php include 'header.php'?>

<head>
  <!-- Include CSS and other meta tags here -->

  <!-- Add the following CSS to justify the form content -->
  <style>

    .fh5co-cover {
      padding: 50px 0; /* Add padding to the header to adjust the size */
    }

    .form-row {
      text-align: justify;
    }

    .form-floating {
      display: block;
      margin-bottom: 10px; /* Add margin between each input (optional) */
    }

    .form-control {
      width: 100%; /* Adjust the font size of the form inputs */
      padding: 8px; /* Adjust the padding of the form inputs */
    }

    /* Optionally, you can adjust the width of the form to make it smaller */
    .signin-form {
      max-width: 300px; /* Set the maximum width of the form */
      margin: 0 auto; /* Center the form horizontally on the page */
    }
  </style>
</head>

<header id="fh5co-header" class="fh5co-cover" >			<div class="col-md-8 col-md-offset-2 text-center">
  <div style="margin: 50px;">
    <!-- Isi elemen Anda di sini -->
  </div>

  <div class="display-t">
    <div class="display-tc animate-box" data-animate-effect="fadeIn">
     <h1 style= "color:black;" >Cari WO</h1>

     <form  action="proses_cari.php" class="signin-form" method="post">
      <div class="form-row">
        <div class="form-floating mb-4">
         <p align="left">Tahun Berdiri</p>
         <select name="tahun" class="form-control">
          <option value="">Tampilkan Semua</option>
          <option value="more-than-2021">2021 ke atas</option>
          <option value="2016-2020">2016 - 2020</option>
          <option value="2011-2015">2011 - 2015</option>
          <option value="2006-2010">2006 - 2010</option>
          <option value="less-than-2005">2005 ke bawah</option>
        </select>
      </div>
      <div class="form-floating mb-4">
        <p align="left">Harga Paket</p>
        <select name="harga" class="form-control">
    <option value="">Tampilkan Semua</option>
    <option value="more-than-25000000">Lebih dari Rp. 25.000.000</option>
    <option value="15000001-25000000">Rp. 15.000.001 - Rp. 25.000.000</option>
    <option value="10000001-15000000">Rp. 10.000.001 - Rp. 15.000.000</option>
    <option value="5000001-10000000">Rp. 5.000.001 - Rp. 10.000.000</option>
    <option value="less-than-5000000">Kurang dari Rp. 5.000.000</option>
</select>

      </div>
      <div class="form-floating mb-4">
       <p align="left">Rating</p>
       <select name="rating" class="form-control">
         <option value="">Tampilkan Semua</option>
         <option value="5.0">5.0</option>
         <option value="4.9">4.9</option>
         <option value="4.8">4.8</option>
         <option value="4.7">4.7</option>
         <option value="less-than-4.6">Kurang dari 4.6</option>
       </select>
     </div>
     <div class="form-floating mb-4">
       <p align="left">Jumlah Kursi</p>
       <select name="jml_kursi" class="form-control">
         <option value="">Tampilkan Semua</option>
         <option value="more-than-200">Lebih dari 200 pcs</option>
         <option value="101-200">101 pcs s/d 200 pcs</option>
         <option value="51-100">51 pcs s/d 100 pcs</option>
         <option value="less-than-50">Kurang dari 50 pcs</option>
       </select>
     </div>
     <div class="form-floating mb-4">
       <p align="left">Jumlah Baju</p>
       <select name="jml_baju" class="form-control">
         <option value="">Tampilkan Semua</option>
         <option value="more-than-3">Lebih dari 3 pasang</option>
         <option value="2">2 pasang</option>
         <option value="1">1 pasang</option>
       </select>
     </div>
     <!-- Submit button -->
     <button type="submit" name="proses" value="proses" class="btn btn-primary btn-block mb-4" style="background-color: black;">
      Cari WO
    </button>

  </form>
</div>
</div>
</div>
</div>
</div>
</div>
</header> <p align="center">
  <small style="color:black;" class="block">&copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</small> </p>

  <div class="gototop js-top">
    <a href="#" class="assets/assets/js-gotop"><i class="icon-arrow-up"></i></a>
  </div>

  <!-- jQuery -->
  <script src="assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="assets/js/jquery.waypoints.min.js"></script>
  <!-- Carousel -->
  <script src="assets/js/owl.carousel.min.js"></script>
  <!-- countTo -->
  <script src="assets/js/jquery.countTo.js"></script>

  <!-- Stellar -->
  <script src="assets/js/jquery.stellar.min.js"></script>
  <!-- Magnific Popup -->
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/magnific-popup-options.js"></script>

  <!-- // <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/0.0.1/prism.min.js"></script> -->
  <script src="assets/js/simplyCountdown.js"></script>
  <!-- Main -->
  <script src="assets/js/main.js"></script>


</body>
</html>