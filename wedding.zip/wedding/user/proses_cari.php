<?php 
session_start();
include '../koneksi.php';

// Menangkap data yang dikirim dari form cari wo
$tahun = $_POST['tahun'];
$harga = $_POST['harga'];
$rating = $_POST['rating'];
$jml_kursi = $_POST['jml_kursi'];
$jml_baju = $_POST['jml_baju'];

try {

// Mulai membangun query awal
$query = "SELECT * FROM alternatif AS a"; // Menggunakan alias 'a' untuk tabel alternatif
$query .= " JOIN preferensi AS p ON a.kd_alternatif = p.kd_alternatif"; // Menambahkan JOIN dengan tabel preferensi

// Menambahkan filter berdasarkan tahun berdiri
if (!empty($tahun)) {
    if ($tahun == "more-than-2021") {
        $query .= " AND a.tahun >= 2021";
    } else if ($tahun == "2016-2020") {
        $query .= " AND a.tahun BETWEEN 2016 AND 2020";
    } else if ($tahun == "2011-2015") {
        $query .= " AND a.tahun BETWEEN 2011 AND 2015";
    } else if ($tahun == "2006-2010") {
        $query .= " AND a.tahun BETWEEN 2006 AND 2010";
    } else if ($tahun == "less-than-2005") {
        $query .= " AND a.tahun <= 2005";
    }
}

// Menambahkan filter berdasarkan harga
if (!empty($harga)) {
    if ($harga == "more-than-25000000") {
        $query .= " AND a.harga >= 25000000";
    } else if ($harga == "15000001-25000000") {
        $query .= " AND a.harga BETWEEN 15000001 AND 25000000";
    } else if ($harga == "10000001-15000000") {
        $query .= " AND a.harga BETWEEN 10000001 AND 15000000";
    } else if ($harga == "5000001-10000000") {
        $query .= " AND a.harga BETWEEN 5000001 AND 10000000";
    } else if ($harga == "less-than-5000000") {
        $query .= " AND a.harga <= 5000000";
    }
}

// Menambahkan filter berdasarkan rating
if (!empty($rating)) {
    if ($rating == "less-than-4.6") {
        $query .= " AND a.rating <= 4.6";
    } else {
        $query .= " AND a.rating = $rating";
    }
}

// Menambahkan filter berdasarkan jumlah kursi
if (!empty($jml_kursi)) {
    if ($jml_kursi == "more-than-200") {
        $query .= " AND a.jml_kursi >= 200";
    } else if ($jml_kursi == "101-200") {
        $query .= " AND a.jml_kursi BETWEEN 101 AND 200";
    } else if ($jml_kursi == "51-100") {
        $query .= " AND a.jml_kursi BETWEEN 51 AND 100";
    } else if ($jml_kursi == "less-than-50") {
        $query .= " AND a.jml_kursi <= 50";
    }
}

// Menambahkan filter berdasarkan jumlah baju
if (!empty($jml_baju)) {
    if ($jml_baju == "more-than-3") {
        $query .= " AND a.jml_baju >= 3";
    } else {
        $query .= " AND a.jml_baju = $jml_baju";
    }
}

// Eksekusi query
$query .= " ORDER BY p.nilai DESC";
$result = mysqli_query($koneksi, $query);

if (!$result) {
        $encoded_data = false; // Jika menggunakan JSON
        header("Location: hasilcari.php?data=$encoded_data");
    }
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    };
    if (count($data)<1) {
        $encoded_data = false; // Jika menggunakan JSON
        header("Location: hasilcari.php?data=$encoded_data");
    }
    else {
        $json_data = json_encode($data);
$encoded_data = urlencode($json_data); // Jika menggunakan JSON
header("Location: hasilcari.php?data=$encoded_data");
}

} catch(Exception $e) {
    $encoded_data = false; // Jika menggunakan JSON
    header("Location: hasilcari.php?data=$encoded_data");
}
?>
