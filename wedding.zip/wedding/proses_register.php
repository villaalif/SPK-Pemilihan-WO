<?php
    include 'koneksi.php';
    session_start();
  $nama_user = $_POST['nama_user'];
  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = md5($_POST['password']);
  $level = 'customer';

    mysqli_query($koneksi, "insert into user values ('NULL','$nama_user','$email','$username','$password','$level')")or die(mysqli_error($koneksi));
    echo "<script>alert('Registrasi Berhasil'); window.location.href = 'index.php';</script>";

?>