<!doctype html>
  <html lang="en">
  <head>
    <link rel="shortcut icon" href="assets/images/logo.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Halaman Login</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>

  <body><br>
    <div class="container-fluid form-container">
      <div class="container login-container">
      <div class="row"> 
              <div class="col-md-5 content-part">
                 <center><h4 class="logo">Woky Wedding Planner</h4></center>

                  <img src="assets/images/logo.png" alt="">

              </div>
              <div class="col-md-7 ">
                   <div class="col-lg-8 col-md-11 login formcol mx-auto">
                       <br><br><h4 align="center">Sign In</h4><br>
                       
                       <form action="proses_login.php" method="POST">
                       <div class="form-floating mb-3">
                        <input type="text" name="username" required="" class="form-control" id="floatingInput" placeholder="Enter Username">
                        <label for="floatingInput">Username</label>
                      </div>
                      <div class="form-floating">
                        <input type="password" name="password" required="" class="form-control" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                      </div>
                      <div class="form-floating">
                       <br><button name="button" class="btn btn-primary">Login</button>
                      </div>
                      </form>

                      <div class="w-80 text-md-left"> Belum memiliki akun? <a href="register.php" >Register</a>
                      </div>
                </div>
                 <br>
              </div>
          </div>
      </div>
    </div> 

  </body>
  </html