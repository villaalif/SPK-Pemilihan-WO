<?php 
include '../koneksi.php';
session_start();

$id = $_SESSION['id'];
$nama = $_POST['nama'];
$email = $_POST['email'];
$username = $_POST['username'];
  $password  = md5($_POST['password']);
  $password1 = $_POST['password'];
  $level = 'admin';

if ($password1=='') {
	mysqli_query($koneksi, "update user set nama_user='$nama',email='$email', username='$username' where id_user='$id'");
	echo "<script>alert('Data Profil Berhasil Diubah'); window.location.href = 'profil.php';</script>";		
}
else {
	mysqli_query($koneksi, "update user set nama_user='$nama',email='$email', username='$username', password='$password' where id_user='$id'");
	echo "<script>alert('Data Profil Berhasil Diubah'); window.location.href = 'profil.php';</script>";	
}


?>