<?php 
include '../koneksi.php';
$kd_kriteria = $_GET['kd_kriteria'];

$query = mysqli_query($koneksi, "select * from kriteria where kd_kriteria='$kd_kriteria'");
mysqli_query($koneksi, "delete from kriteria where kd_kriteria='$kd_kriteria'");
echo "<script>alert('Data Bobot Berhasil Dihapus'); window.location.href = 'menukriteria.php';</script>";
?>