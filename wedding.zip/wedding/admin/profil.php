<?php include 'header.php'; ?>
     <div id="layoutSidenav_content">
        <main>
        <div class="container-fluid px-4">
        <h1 class="mt-4">Profil Admin</h1>
            <br><br>
            <?php 
            include '../koneksi.php';
            $id = $_SESSION['id'];
            $data = mysqli_query($koneksi, "select * from user where level='admin'"); 
            while ($b = mysqli_fetch_assoc($data)) { ?>

                <div class="row">
                 <form action="proses_editprofil.php" method="post" enctype="multipart/form-data">
                  <div class="container">
                     <div class="form-group row">
                     <div class="form-group row">
                        <label  class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-5">
                         <input type="nama_user" class="form-control" name="nama" id="nama" placeholder=""required="required" value="<?php echo $b['nama_user'] ?>" >
                       </div>
                     </div><br><br>

                        <div class="form-group row">
                          <label  class="col-sm-2 col-form-label">Email</label>
                          <div class="col-sm-5">
                            <input type="text" class="form-control" name="email" id="email" value="<?php echo $b['email']; ?>">
                          </div>
                        </div>
                        <br><br>

                        <div class="form-group row">
                          <label  class="col-sm-2 col-form-label">Username</label>
                          <div class="col-sm-5">
                            <input type="text" class="form-control" name="username" id="username" value="<?php echo $b['username']; ?>">
                          </div>
                        </div>
                        <br><br>

                        <div class="form-group row">
                          <label  class="col-sm-2 col-form-label">Password</label>
                          <div class="col-sm-5">
                           <input type="password" class="form-control" name="password" id="password" placeholder="Masukkan Password"><font size="2px" color="grey" ><i>(boleh dikosongkan jika tidak ingin mengganti password)</i></font>
                           </div>
                         </div>
                         
                         <p></p><p align="center"><button type="submit" class=" btn btn-success" name="edit">Edit</button></p>
                        </form>
                      </div>
                        <?php } ?>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                             <div class="text-muted">Copyright &copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
