<?php include 'header.php'; ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Data Kriteria</h1>
                        <br><br>
                            <?php 
                        include '../koneksi.php';
                        $kd= $_GET['kd_kriteria'];
                        $data = mysqli_query($koneksi, "select * from kriteria where kd_kriteria='$kd'"); 
                        while ($c = mysqli_fetch_array($data)){ ?>
                <div class="row">
                 <form action="proses_editbbt.php" method="post" enctype="multipart/form-data">
                  <div class="container">
                    <div class="form-group row">

                    <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Nama Kriteria</label>
                        <div class="col-sm-5">
                        <input type="hidden" name="kd_kriteria" id="kd_kriteria" value="<?php echo $c['kd_kriteria'];?>">

                         <input type="text" class="form-control" name="nama_kriteria" id="nama_kriteria" placeholder="" value="<?= $c['nama_kriteria']?>" >
                       </div>
                     </div><br><br>
                     <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Tipe Kriteria</label>
                        <div class="col-sm-5">                              
                         <select class="form-control" name="tipe_kriteria">
                            <option value="<?= $c['tipe_kriteria']?>"><?= $c['tipe_kriteria']?></option>
                            <option value="Cost">Cost</option>
                            <option value="Benefit">Benefit</option>
                         </select>
                       </div>
                     </div><br><br>

                     <div class="form-group row">
                      <label  class="col-sm-3 col-form-label">Bobot</label>
                      <div class="col-sm-5">
                        <input type="text" class="form-control" name="bobot" required="" id="bobot" value="<?= $c['bobot']?>"></div>
                      </div>
                      <br><br>

                         <br><br><br>
                         <p align="center"><button type="submit" class=" btn btn-success" name="simpan">Simpan</button>
                          <a href="menukriteria.php" class="btn btn-primary">Kembali</a> </p>

                          <br>
                          <br>

                        </form>
                        </div>
                        <?php } ?>
                    </div>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</div>
                            
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>