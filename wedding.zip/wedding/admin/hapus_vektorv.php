<?php
include '../koneksi.php';

$query_hapus = mysqli_query($koneksi, "DELETE FROM preferensi");

if ($query_hapus) {
    echo "<script>alert('Data Vektor V Berhasil Dihapus'); window.location.href = 'menu_vektorv.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data Vektor V'); window.location.href = 'menu_vektorv.php';</script>";
}
?>