<?php 
include '../koneksi.php';
session_start();
  $kd = $_POST['kd_alternatif'];
  $id_user = intval($_SESSION['id']);
  $nama = $_POST['nama_alternatif'];
  $tahun = $_POST['tahun'];
  $harga  = $_POST['harga'];
  $rating = $_POST['rating'];
  $jml_kursi  = $_POST['jml_kursi'];
  $jml_baju  = $_POST['jml_baju'];

  mysqli_query($koneksi, "INSERT INTO alternatif VALUES ('$kd','$id_user', '$nama', '$tahun', '$harga', '$rating','$jml_kursi', '$jml_baju')" ) or die (mysqli_error($koneksi));
  echo "<script>alert('Data Alternatif Berhasil Ditambahkan'); window.location.href = 'menualternatif.php';</script>"
?>