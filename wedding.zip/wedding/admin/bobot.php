<?php 
include '../koneksi.php';
	
	$query_bobotper =  mysqli_query($koneksi, "SELECT * FROM bobot" );
	$count_bobotper = mysqli_num_rows($query_bobotper);

	if ($count_bobotper>0){
		echo "<script>alert('Nilai Bobot Sudah Ada'); window.location.href = 'menubobot.php';</script>";
	}
	$query_bobot =  mysqli_query($koneksi, "SELECT * FROM kriteria ORDER BY kd_kriteria ASC" );
	$bobots = array(); // Array untuk menyimpan bobot

while ($data_bobot = mysqli_fetch_assoc($query_bobot)) {
    $bobots[] = $data_bobot['bobot']; // Memasukkan nilai bobot ke dalam array bobots
}

// Mengisi nilai bobot ke variabel berdasarkan indeksnya masing-masing
$B1 = $bobots[0];
$B2 = $bobots[1];
$B3 = $bobots[2];
$B4 = $bobots[3];
$B5 = $bobots[4];

	
$weight = ($B1+$B2+$B3+$B4+$B5);

$C1 = round(($B1/$weight),2);
$C2 = round(($B2/$weight),2);
$C3 = round(($B3/$weight),2);
$C4 = round(($B4/$weight),2);
$C5 = round(($B5/$weight),2);

	$p_c1 = 'W1';
	$p_c2 = 'W2';
	$p_c3 = 'W3';
	$p_c4 = 'W4';
	$p_c5 = 'W5';

	$sql = "INSERT INTO bobot VALUES ('$p_c1', 'K1', '$C1'),
	('$p_c2', 'K2', '$C2'),
	('$p_c3', 'K3', '$C3'),
	('$p_c4', 'K4', '$C4'),
	('$p_c5', 'K5', '$C5')";

	$result = mysqli_query($koneksi, $sql) or die (mysqli_error());
	$count = mysqli_affected_rows($koneksi);

	if ($count>0){
		echo "<script>alert('Proses Perbaikan Bobot Selesai'); window.location.href = 'menubobot.php';</script>";
	}

 ?>