<?php include 'header.php'; ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Data Nilai Bobot Perbaikan</h1>
            
            
            <div class="card mb-4">
                <div class="card-body">
                 <div class="pull-left">
                <a href="bobot.php" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Data Nilai Bobot</a></div><font size="2px" color="grey" ><i>(tidak perlu di klik jika data sudah ada)</i></font><br><br>
                    <table id="datatablesSimple">
                     <thead>
                        <tr>
                          <th>Kode Bobot</th>
                          <th>Kode Alternatif</th>
                          <th>Nilai Perbaikan</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php  
                    include '../koneksi.php';
                    $query_tampil = mysqli_query($koneksi, "SELECT * FROM bobot" ) or die (mysqli_error($koneksi));

                    while ($b = mysqli_fetch_assoc($query_tampil)) {
                        ?>

                        <tr>
                            <td><?= $b['kd_bobot']; ?></td>
                            <td ><?= $b['kd_kriteria']; ?></td>
                            <td ><?= $b['nilai_perbaikan']; ?></td>
                            
                      </tr>
                      
                      <?php  
                  }
                  ?>     
              </tbody>
          </table>
      </div>
  </div>
</div>
</main>
<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</div>
            
        </div>
    </div>
</footer>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="assets/js/scripts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<script src="assets/js/datatables-simple-demo.js"></script>
</body>
</html>
