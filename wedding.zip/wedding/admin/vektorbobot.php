<?php 
include '../koneksi.php';

	$query_bobotsper =  mysqli_query($koneksi, "SELECT * FROM bobots" );
	$count_bobotsper = mysqli_num_rows($query_bobotsper);

	if ($count_bobotsper>0){
		echo "<script>alert('Nilai Vektor S Sudah Ada'); window.location.href = 'menu_vektors.php';</script>";
	}

	$query_bobot =  mysqli_query($koneksi, "SELECT * FROM bobot ORDER BY kd_bobot ASC" );
	$bobots = array(); // Array untuk menyimpan bobot

while ($data_bobot = mysqli_fetch_assoc($query_bobot)) {
    $bobots[] = $data_bobot['nilai_perbaikan']; // Memasukkan nilai bobot ke dalam array bobots
}

// Mengisi nilai bobot ke variabel berdasarkan indeksnya masing-masing
$C1 = $bobots[0];
$C2 = $bobots[1];
$C3 = $bobots[2];
$C4 = $bobots[3];
$C5 = $bobots[4];

$query_alternatif =  mysqli_query($koneksi, "SELECT * FROM alternatif ORDER BY kd_alternatif ASC" );
	$tahun = array(); // Array untuk menyimpan bobot
	$harga = array(); // Array untuk menyimpan bobot
	$rating = array(); // Array untuk menyimpan bobot
	$jml_kursi = array(); // Array untuk menyimpan bobot
	$jml_baju = array(); // Array untuk menyimpan bobot

while ($data_alternatif = mysqli_fetch_assoc($query_alternatif)) {
    $tahun[] = $data_alternatif['tahun']; // Memasukkan nilai bobot ke dalam array bobots
    $harga[] = $data_alternatif['harga']; // Memasukkan nilai bobot ke dalam array bobots
    $rating[] = $data_alternatif['rating']; // Memasukkan nilai bobot ke dalam array bobots
    $jml_kursi[] = $data_alternatif['jml_kursi']; // Memasukkan nilai bobot ke dalam array bobots
    $jml_baju[] = $data_alternatif['jml_baju']; // Memasukkan nilai bobot ke dalam array bobots
    $p_c[] = $data_alternatif['kd_alternatif'];
}

	$T = array();
	$H = array();
	$R = array();
	$JK = array();
	$JB = array();

	for ($i = 0; $i < count($tahun); $i++) {
    	$T[$i] = $tahun[$i];
    	$H[$i] = $harga[$i];
    	$R[$i] = $rating[$i];
    	$JK[$i] = $jml_kursi[$i];
    	$JB[$i] = $jml_baju[$i];
	}

	$S = array();
	$n_s = array();

	for ($j = 0; $j < count($T); $j++) {
		$b_t[$j] = round(pow($T[$j],-$C1), 4);
		$b_h[$j] = round(pow($H[$j],-$C2), 4);
		$b_r[$j] = round(pow($R[$j],$C3), 4);
		$b_jk[$j] = round(pow($JK[$j],$C4), 4);
		$b_jb[$j] = round(pow($JB[$j],$C5), 4);

		$S[$j] = round(($b_t[$j] * $b_h[$j] * $b_r[$j] * $b_jk[$j] * $b_jb[$j]), 4);
		$n_s[$j] = 'S' . ($j + 1);
	}

	$sql = "INSERT INTO bobots (kd_bobots, kd_alternatif, nilai) VALUES ";

	$values = array();
	for ($j = 0; $j < count($T); $j++) {
    	$values[] = "('$n_s[$j]', '$p_c[$j]', '$S[$j]')";
	}

	$sql .= implode(", ", $values); // Menggabungkan nilai-nilai yang akan dimasukkan


	$result = mysqli_query($koneksi, $sql) or die (mysqli_error());
	$count = mysqli_affected_rows($koneksi);

	if ($count>0){
		echo "<script>alert('Proses Perhitungan Vektor S Selesai'); window.location.href = 'menu_vektors.php';</script>";
	}

 ?>