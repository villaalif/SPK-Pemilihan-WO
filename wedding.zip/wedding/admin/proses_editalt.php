<?php 

include '../koneksi.php';
session_start();
  $kd = $_POST['kd_alternatif'];
  $id_user = intval($_SESSION['id']);
  $nama = $_POST['nama_alternatif'];
  $tahun = $_POST['tahun'];
  $harga  = $_POST['harga'];
  $rating = $_POST['rating'];
  $jml_kursi  = $_POST['jml_kursi'];
  $jml_baju  = $_POST['jml_baju'];

mysqli_query($koneksi, "update alternatif set nama_alternatif='$nama', tahun='$tahun', harga='$harga', rating='$rating', jml_kursi='$jml_kursi', jml_baju= '$jml_baju'  where kd_alternatif='$kd'");
	echo "<script>alert('Data Alternatif Diedit'); window.location.href = 'menualternatif.php';</script>";
 ?>