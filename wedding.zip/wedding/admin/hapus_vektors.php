<?php
include '../koneksi.php';

$query_hapus = mysqli_query($koneksi, "DELETE FROM bobots");

if ($query_hapus) {
    echo "<script>alert('Data Vektor S Berhasil Dihapus'); window.location.href = 'menu_vektors.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data Vektor S'); window.location.href = 'menu_vektors.php';</script>";
}
?>