<?php 
include '../koneksi.php';
$kd_alternatif = $_GET['kd_alternatif'];

$query = mysqli_query($koneksi, "select * from alternatif where kd_alternatif='$kd_alternatif'");
mysqli_query($koneksi, "delete from alternatif where kd_alternatif='$kd_alternatif'");
echo "<script>alert('Data Alternatif Berhasil Dihapus'); window.location.href = 'menualternatif.php';</script>";
?>

