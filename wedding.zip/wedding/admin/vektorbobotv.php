<?php 
include '../koneksi.php';

	$query_bobotsper =  mysqli_query($koneksi, "SELECT * FROM preferensi" );
	$count_bobotsper = mysqli_num_rows($query_bobotsper);

	if ($count_bobotsper>0){
		echo "<script>alert('Nilai Vektor V Sudah Ada'); window.location.href = 'menu_vektorv.php';</script>";
	}

	$query_bobot =  mysqli_query($koneksi, "SELECT * FROM bobots ORDER BY kd_bobots ASC" );
	$bobots = array(); // Array untuk menyimpan bobot

	while ($data_bobot = mysqli_fetch_assoc($query_bobot)) {
    	$S[] = $data_bobot['nilai']; // Memasukkan nilai bobot ke dalam array bobots
    	$p_c[] = $data_bobot['kd_alternatif'];
	}

	$hasil = array_sum($S);

	$sql = "INSERT INTO preferensi (kd_prefrensi, kd_alternatif, nilai) VALUES ";

	$values = array();

	 for ($j = 0; $j < count($S); $j++) {
        $n_v = 'V' . ($j + 1);
        $nilai = round(($S[$j] / $hasil), 4);
        $values[] = "('$n_v', '$p_c[$j]', '$nilai')";
    }



	$sql .= implode(", ", $values);

	$result = mysqli_query($koneksi, $sql) or die (mysqli_error());
	$count = mysqli_affected_rows($koneksi);

	if ($count>0){
		echo "<script>alert('Proses Perhitungan Preferensi Selesai'); window.location.href = 'menu_vektorv.php';</script>";
	}

 ?>