<?php include 'header.php'; ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Edit Data Alternatif</h1>
                        <br><br>
                            <?php 
                        include '../koneksi.php';
                        $kd= $_GET['kd_alternatif'];
                        $data = mysqli_query($koneksi, "select * from alternatif where kd_alternatif='$kd'"); 
                        while ($c = mysqli_fetch_array($data)){ ?>
                <div class="row">
                 <form action="proses_editalt.php" method="post" enctype="multipart/form-data">
                  <div class="container">
                    <div class="form-group row">

                    <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Nama Alternatif</label>
                        <div class="col-sm-5">
                        <input type="hidden" name="kd_alternatif" id="kd_alternatif" value="<?php echo $c['kd_alternatif'];?>">

                         <input type="text" class="form-control" name="nama_alternatif" id="nama_alternatif" placeholder="" value="<?= $c['nama_alternatif']?>" >
                       </div>
                     </div><br><br>
                     <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Tahun</label>
                        <div class="col-sm-5">                              
                         <input type="text" class="form-control" name="tahun" id="tahun" placeholder="" value="<?= $c['tahun']?>" >
                       </div>
                     </div><br><br>

                     <div class="form-group row">
                      <label  class="col-sm-3 col-form-label">Harga</label>
                      <div class="col-sm-5">
                        <input type="text" class="form-control" name="harga" required="" id="harga" value="<?= $c['harga']?>"></div>
                      </div>
                      <br><br>

                      <div class="form-group row">
                      <label  class="col-sm-3 col-form-label">Rating</label>
                      <div class="col-sm-5">
                        <input type="text" class="form-control" name="rating" required="" id="rating" value="<?= $c['rating']?>" ></div>
                      </div>
                      <br><br>

                      <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Jumlah Kursi</label>
                        <div class="col-sm-5">
                          <input type="text" class="form-control" name="jml_kursi" id="jml_kursi" placeholder="" value="<?= $c['jml_kursi']?>" > </div>
                        </div>
                        <br><br>

                        <div class="form-group row">
                        <label  class="col-sm-3 col-form-label">Jumlah Baju</label>
                        <div class="col-sm-5">
                          <input type="text" class="form-control" name="jml_baju" id="jml_baju" placeholder="" value="<?= $c['jml_baju']?>" > </div>
                        </div>
                        <br><br>

                         <br><br><br>
                         <p align="center"><button type="submit" class=" btn btn-success" name="simpan">Simpan</button>
                          <a href="menualternatif.php" class="btn btn-primary">Kembali</a> </p>

                          <br>
                          <br>

                        </form>
                        </div>
                        <?php } ?>
                    </div>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Sistem Pengambilan Keputusan Pemilihan Wedding Organizer</div>
                            
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>