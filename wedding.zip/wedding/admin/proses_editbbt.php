<?php 

include '../koneksi.php';
session_start();
  $kd = $_POST['kd_kriteria'];
  $id = intval($_SESSION['id_user']);
  $nama = $_POST['nama_kriteria'];
  $tipe = $_POST['tipe_kriteria'];
  $bobot  = $_POST['bobot'];

mysqli_query($koneksi, "update kriteria set nama_kriteria='$nama', tipe_kriteria='$tipe', bobot='$bobot' where kd_kriteria='$kd'");
	echo "<script>alert('Data Kriteria Diedit'); window.location.href = 'menukriteria.php';</script>";
 ?>