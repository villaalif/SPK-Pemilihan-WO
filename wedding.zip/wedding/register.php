<!doctype html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Halaman Register SPK pemilihan WO</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>

  <body><br>
    <div class="container-fluid form-container">
      <div class="container login-container">
      <div class="row"> 
                 <center><br><h4 class="logo">Form  Register</h4></center>
                 <br><center><h4>Sign In</h4><br></center>

              <div class="col-md-10 ">
                   <div class="col-lg-8 col-md-11 login formcol mx-auto">
                       <form action="proses_register.php" method="POST">
                       	<div class="form-floating mb-3">
                        <input type="text" name="nama_user" required="" class="form-control" id="nama_user" placeholder="Enter Nama User">
                        <label for="floatingInput">Nama User</label>
                      </div>
                      <div class="form-floating mb-3">
                        <input type="text" name="email" required="" class="form-control" id="email" placeholder="Enter Email">
                        <label for="floatingInput">Email</label>
                      </div>
                      <div class="form-floating mb-3">
                        <input type="text" name="username" required="" class="form-control" id="username" placeholder="Enter Username">
                        <label for="floatingInput">Username</label>
                      </div>
                      <div class="form-floating">
                        <input type="password" name="password" required="" class="form-control" id="password" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                      </div>
                      <div class="form-floating">
                       <br><button name="button" type="submit" class="btn btn-success">Daftar</button>
                      <a href="index.php" class="btn btn-primary">Kembali</a>
                      </div>
                      </form>
                 
                </div>
                 <br>
              </div>
          </div>
      </div>
    </div> 

  </body>
  </html