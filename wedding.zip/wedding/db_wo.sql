-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Sep 2023 pada 18.23
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_wo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alternatif`
--

CREATE TABLE `alternatif` (
  `kd_alternatif` char(5) NOT NULL,
  `id_user` int(5) NOT NULL,
  `nama_alternatif` varchar(35) NOT NULL,
  `tahun` varchar(5) NOT NULL,
  `harga` varchar(35) NOT NULL,
  `rating` varchar(5) NOT NULL,
  `jml_kursi` varchar(5) NOT NULL,
  `jml_baju` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `alternatif`
--

INSERT INTO `alternatif` (`kd_alternatif`, `id_user`, `nama_alternatif`, `tahun`, `harga`, `rating`, `jml_kursi`, `jml_baju`) VALUES
('A1', 1, 'Wedding Dian', '1997', '18000000', '4.7', '100', '2'),
('A2', 1, 'Global Wedding', '2015', '15000000', '4.8', '100', '2'),
('A3', 1, 'Sumayyah Wedding', '2014', '8000000', '4.8', '80', '2'),
('A4', 1, 'Kharisma Wedding', '1995', '10000000', '4.8', '50', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bobot`
--

CREATE TABLE `bobot` (
  `kd_bobot` char(5) NOT NULL,
  `kd_kriteria` char(5) NOT NULL,
  `nilai_perbaikan` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `bobot`
--

INSERT INTO `bobot` (`kd_bobot`, `kd_kriteria`, `nilai_perbaikan`) VALUES
('W1', 'K1', 0.17),
('W2', 'K2', 0.33),
('W3', 'K3', 0.17),
('W4', 'K4', 0.25),
('W5', 'K5', 0.08);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bobots`
--

CREATE TABLE `bobots` (
  `kd_bobots` char(5) NOT NULL,
  `kd_alternatif` char(5) NOT NULL,
  `nilai` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `bobots`
--

INSERT INTO `bobots` (`kd_bobots`, `kd_alternatif`, `nilai`) VALUES
('S1', 'A1', 0.0048),
('S2', 'A2', 0.0051),
('S3', 'A3', 0.006),
('S4', 'A4', 0.0047);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kriteria`
--

CREATE TABLE `kriteria` (
  `kd_kriteria` char(5) NOT NULL,
  `id_user` int(5) NOT NULL,
  `nama_kriteria` varchar(35) NOT NULL,
  `tipe_kriteria` enum('Benefit','Cost') NOT NULL,
  `bobot` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `kriteria`
--

INSERT INTO `kriteria` (`kd_kriteria`, `id_user`, `nama_kriteria`, `tipe_kriteria`, `bobot`) VALUES
('K1', 1, 'Tahun', 'Cost', 2),
('K2', 1, 'Harga', 'Cost', 4),
('K3', 1, 'Rating', 'Benefit', 2),
('K4', 1, 'Jumlah Kursi', 'Benefit', 3),
('K5', 1, 'Jumlah Pasang Baju', 'Benefit', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `preferensi`
--

CREATE TABLE `preferensi` (
  `kd_prefrensi` char(5) NOT NULL,
  `kd_alternatif` char(5) NOT NULL,
  `nilai` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `preferensi`
--

INSERT INTO `preferensi` (`kd_prefrensi`, `kd_alternatif`, `nilai`) VALUES
('V1', 'A1', 0.233),
('V2', 'A2', 0.2476),
('V3', 'A3', 0.2913),
('V4', 'A4', 0.2282);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(5) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` enum('admin','customer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `email`, `username`, `password`, `level`) VALUES
(1, 'admin1', 'admin27@gmail.com', 'admin1', 'b59c67bf196a4758191e42f76670ceba', 'admin'),
(2, 'alip', 'alip@gmail.com', 'alip', 'b59c67bf196a4758191e42f76670ceba', 'customer'),
(3, 'pris', 'prisi@gmail.com', 'prisi', '81dc9bdb52d04dc20036dbd8313ed055', 'customer'),
(5, 'priska', 'prisi@gmail.com', 'prisi', 'b59c67bf196a4758191e42f76670ceba', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`kd_alternatif`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `bobot`
--
ALTER TABLE `bobot`
  ADD PRIMARY KEY (`kd_bobot`),
  ADD KEY `kd_kriteria` (`kd_kriteria`);

--
-- Indeks untuk tabel `bobots`
--
ALTER TABLE `bobots`
  ADD PRIMARY KEY (`kd_bobots`),
  ADD KEY `bobots_ibfk_1` (`kd_alternatif`);

--
-- Indeks untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`kd_kriteria`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `preferensi`
--
ALTER TABLE `preferensi`
  ADD PRIMARY KEY (`kd_prefrensi`),
  ADD KEY `preferensi_ibfk_1` (`kd_alternatif`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `alternatif`
--
ALTER TABLE `alternatif`
  ADD CONSTRAINT `alternatif_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `bobot`
--
ALTER TABLE `bobot`
  ADD CONSTRAINT `bobot_ibfk_1` FOREIGN KEY (`kd_kriteria`) REFERENCES `kriteria` (`kd_kriteria`);

--
-- Ketidakleluasaan untuk tabel `bobots`
--
ALTER TABLE `bobots`
  ADD CONSTRAINT `bobots_ibfk_1` FOREIGN KEY (`kd_alternatif`) REFERENCES `alternatif` (`kd_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  ADD CONSTRAINT `kriteria_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Ketidakleluasaan untuk tabel `preferensi`
--
ALTER TABLE `preferensi`
  ADD CONSTRAINT `preferensi_ibfk_1` FOREIGN KEY (`kd_alternatif`) REFERENCES `alternatif` (`kd_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
